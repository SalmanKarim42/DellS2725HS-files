import re

from request_parsers import errors
from request_parsers import json

_HOSTNAME_PATTERN = re.compile(r'^[-0-9a-z]{1,63}$')


def parse_hostname(request):
    """Parses the hostname property from the request.

    Parses the hostname from a JSON request and checks whether the hostname is
    valid according to the rules in

    Args:
        request: Flask request with the hostname field as string.

    Returns:
        The parsed and validated hostname (as string).

    Raises:
        InvalidHostnameError: If the hostname is invalid.
    """
    # pylint: disable=unbalanced-tuple-unpacking
    (hostname,) = json.parse_json_body(request, required_fields=['hostname'])

    if not isinstance(hostname, str):
        raise errors.InvalidHostnameError('The hostname is not a string.')
    if hostname == 'localhost':
        raise errors.InvalidHostnameError('The hostname cannot be localhost.')
    if hostname.startswith('-'):
        raise errors.InvalidHostnameError('The hostname cannot start with "-".')
    if _HOSTNAME_PATTERN.match(hostname) is None:
        raise errors.InvalidHostnameError(
            'The hostname contains invalid characters.')

    return hostname
